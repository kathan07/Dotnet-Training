﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MCP.Core.Chat
{
    public class WorkflowPayload
    {
        public List<McpRequest> Workflow { get; set; } = new();
    }
}
