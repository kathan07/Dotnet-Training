﻿namespace MCP.Core.Chat
{
    public class McpRequest
    {
        public string tool { get; set; } = string.Empty;
        public Dictionary<string, object?> Parameters { get; set; } = new Dictionary<string, object>();
    }
}
