﻿namespace MCP.Core.Chat
{
    public class McpResponse
    {
        public string? ToolName { get; set; }
        public List<McpReponseContent>? Content { get; set; }
    }
}
