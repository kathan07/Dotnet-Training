﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MCP.Core.Chat
{
    public class McpReponseContent
    {
        public string? Type { get; set; }
        public string? Text { get; set; }
    }
}
