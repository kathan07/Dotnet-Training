﻿using ModelContextProtocol.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MCP.Business.MCP
{
    public interface IMcpManager
    {
        Task<IList<McpClientTool>> GetTools(McpClient mcpClient);
        Task<string> ProcessQuery(string query, string token);
        IAsyncEnumerable<string> ProcessQueryStream(string query, string token);
    }
}
