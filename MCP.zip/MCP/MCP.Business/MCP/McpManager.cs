﻿using MCP.Business.Services.MCPCache;
using MCP.Business.Services.SemanticKernel;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;
using ModelContextProtocol.Client;
using System.Text.Json;

namespace MCP.Business.MCP
{
    public class McpManager: IMcpManager
    {
        private readonly IMcpClientCache _clientCache;
        private readonly Kernel _kernel;
        private readonly IChatCompletionService _chat;

        public McpManager(IMcpClientCache clientCache, ISemanticKernelService semanticKernelService)
        {
            _clientCache = clientCache;
            _kernel = semanticKernelService.Kernel;
            _chat = _kernel.GetRequiredService<IChatCompletionService>();
        }


        public async Task<IList<McpClientTool>> GetTools(McpClient mcpClient)
        {
            IList<McpClientTool> tools = await mcpClient.ListToolsAsync();
            return tools;
        }

        /// <summary>
        /// Process query with TRUE streaming from LLM
        /// </summary>
        public async IAsyncEnumerable<string> ProcessQueryStream(string query, string token)
        {
            McpClient mcpClient = await _clientCache.GetOrCreateMcpClient(token);
            ChatHistory history = new ChatHistory();

            // Get available tools and register them as kernel functions
            IList<McpClientTool> tools = await GetTools(mcpClient);

            // Clear existing plugins to avoid duplicates
            KernelPlugin? existing = _kernel.Plugins.FirstOrDefault(p => p.Name == "McpTools");
            if (existing != null)
            {
                _kernel.Plugins.Remove(existing);
            }

            // Create ONE plugin containing ALL MCP tools
            var plugin = KernelPluginFactory.CreateFromFunctions( "McpTools", tools.Select(aiFunction => aiFunction.AsKernelFunction()) );

            _kernel.Plugins.Add(plugin);


            var settings = new OpenAIPromptExecutionSettings
            {
                Temperature = 0.1,
                ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions
            };

            history.AddUserMessage(query);

            // Stream the response - Semantic Kernel handles tool invocation automatically
            await foreach (var streamingUpdate in _chat.GetStreamingChatMessageContentsAsync(
                history,
                settings,
                _kernel))
            {
                if (!string.IsNullOrEmpty(streamingUpdate.Content))
                {
                    yield return JsonSerializer.Serialize(new
                    {
                        type = "text",
                        content = streamingUpdate.Content
                    });
                }
            }
        }

        /// <summary>
        /// Non-streaming method for compatibility
        /// </summary>
        public async Task<string> ProcessQuery(string query, string token)
        {
            List<string> results = new List<string>();
            await foreach (var chunk in ProcessQueryStream(query, token))
            {
                try
                {
                    var data = JsonSerializer.Deserialize<JsonElement>(chunk);
                    if (data.TryGetProperty("type", out var typeProperty) &&
                        typeProperty.GetString() == "text" &&
                        data.TryGetProperty("content", out var contentProperty))
                    {
                        results.Add(contentProperty.GetString() ?? "");
                    }
                }
                catch { }
            }
            return string.Join("", results);
        }

        //private async Task<ModelContextProtocol.Protocol.CallToolResult> InvokeTool(McpRequest request, McpClient mcpClient)
        //{
        //    Dictionary<string, object?> arguments = request.Parameters;
        //    ModelContextProtocol.Protocol.CallToolResult result = await mcpClient.CallToolAsync(request.tool, arguments);
        //    if (result == null || result.Content == null) return null;
        //    return result;

        //}
    }
}
