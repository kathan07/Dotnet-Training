﻿using ModelContextProtocol.Client;

namespace MCP.Business.Services.MCP
{
    public interface IMcpClientFactory
    {
        Task<McpClient> CreateMcpClient(string token);
    }
}
