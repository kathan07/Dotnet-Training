﻿using ModelContextProtocol.Client;

namespace MCP.Business.Services.MCP
{
    public class McpClientFactory: IMcpClientFactory
    {
        public async Task<McpClient> CreateMcpClient(string token)
        {
            // MCP transport options
            HttpClientTransportOptions transportOptions = new HttpClientTransportOptions
            {
                Endpoint = new Uri("https://mcp-server-hgot.onrender.com/sse"),
                //Endpoint = new Uri("http://localhost:8080/sse"),
                AdditionalHeaders = new Dictionary<string, string>
                {
                    { "Authorization", $"Bearer {token}" }
                }
            };
            HttpClientTransport transport = new HttpClientTransport(transportOptions);

            // MCP client (blocking async call in constructor)
            return await McpClient.CreateAsync(transport);
        }
    }
}
