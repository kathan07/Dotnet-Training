﻿using Microsoft.SemanticKernel;

namespace MCP.Business.Services.SemanticKernel
{
    public interface ISemanticKernelService
    {
        Kernel Kernel { get; }
    }
}
