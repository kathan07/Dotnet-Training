﻿using MCP.Business.Services.MCPCache;
using Microsoft.SemanticKernel;

namespace MCP.Business.Services.SemanticKernel
{
    public class SemanticKernelService: ISemanticKernelService
    {
        public Kernel Kernel { get; }

        public SemanticKernelService(IMcpClientCache clientCache)
        {
            IKernelBuilder kb = Kernel.CreateBuilder();

            kb.AddOpenAIChatCompletion(
                modelId: "gpt-4o-mini",
                apiKey: "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"
            );

            Kernel = kb.Build();
        }
    }
}
