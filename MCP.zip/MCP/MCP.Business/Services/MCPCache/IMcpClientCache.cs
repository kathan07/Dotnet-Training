﻿using ModelContextProtocol.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MCP.Business.Services.MCPCache
{
    public interface IMcpClientCache
    {
        Task<McpClient> GetOrCreateMcpClient(string token);
    }
}
