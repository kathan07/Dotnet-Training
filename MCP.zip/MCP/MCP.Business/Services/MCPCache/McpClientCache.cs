﻿using MCP.Business.Services.MCP;
using Microsoft.Extensions.Caching.Memory;
using ModelContextProtocol.Client;

namespace MCP.Business.Services.MCPCache
{
    public class McpClientCache: IMcpClientCache
    {
        private readonly IMemoryCache _memoryCache;
        private readonly IMcpClientFactory _factory;

        public McpClientCache(IMemoryCache memoryCache, IMcpClientFactory factory)
        {
            _memoryCache = memoryCache;
            _factory = factory;
        }

        public Task<McpClient> GetOrCreateMcpClient(string token)
        {
            return _memoryCache.GetOrCreateAsync(token, async entry =>
            {
                // SET EXPIRATION HERE
                entry.SetSlidingExpiration(TimeSpan.FromMinutes(20));
                entry.SetAbsoluteExpiration(TimeSpan.FromHours(2));

                // Prevent parallel creation with Lazy<Task<T>>
                var lazy = new Lazy<Task<McpClient>>(() => _factory.CreateMcpClient(token));

                // The cache stores lazy.Value (the task)
                return await lazy.Value;
            });
        }

    }
}
