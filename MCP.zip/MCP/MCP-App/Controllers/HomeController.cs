using MCP.Business.MCP;
using MCP.Core.Chat;
using Microsoft.AspNetCore.Mvc;

namespace MCP_App.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HomeController : ControllerBase
    {
        

        private readonly ILogger<HomeController> _logger;
        private readonly IMcpManager _mcpManager;

        public HomeController(ILogger<HomeController> logger, IMcpManager mcpManager)
        {
            _logger = logger;
            _mcpManager = mcpManager;
        }

        [HttpPost]
        public async Task Index([FromBody] RequestDto request)
        {
            Response.Headers.Append("Content-Type", "text/event-stream");
            Response.Headers.Append("Cache-Control", "no-cache");
            Response.Headers.Append("X-Accel-Buffering", "no");
            Response.Headers.Append("Connection", "keep-alive");

            try
            {
                await foreach (var chunk in _mcpManager.ProcessQueryStream(request.Prompt, request.Token))
                {
                    await Response.WriteAsync($"data: {chunk}\n\n");
                    await Response.Body.FlushAsync();
                }

                // Send completion signal
                await Response.WriteAsync("data: [DONE]\n\n");
                await Response.Body.FlushAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error processing query");
                await Response.WriteAsync($"data: {{\"error\": \"{ex.Message}\"}}\n\n");
                await Response.Body.FlushAsync();
            }
        }
    }
}
