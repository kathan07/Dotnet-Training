﻿
using MCP.Business.MCP;
using MCP.Business.Services.MCP;
using MCP.Business.Services.MCPCache;
using MCP.Business.Services.SemanticKernel;
using Microsoft.AspNetCore.Server.Kestrel.Core;

namespace MCP_App
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.

            // ✅ Configure Kestrel for pass-through streaming
            builder.WebHost.ConfigureKestrel(options =>
            {
                options.Limits.MinResponseDataRate = null;
                options.Limits.MinRequestBodyDataRate = null;
            });

            builder.Services.Configure<KestrelServerOptions>(options =>
            {
                options.AllowSynchronousIO = false;
            });


            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            builder.Services.AddMemoryCache();
            // Register the client service as Singleton (created once for the application lifetime)
            builder.Services.AddSingleton<IMcpClientFactory, McpClientFactory>();
            builder.Services.AddSingleton<IMcpClientCache, McpClientCache>();
            builder.Services.AddSingleton<ISemanticKernelService, SemanticKernelService>();
            // Register the manager as Scoped (new instance per request, but uses singleton clients)
            builder.Services.AddScoped<IMcpManager, McpManager>();

            // ? Allow all CORS (for development only)
            builder.Services.AddCors(options =>
            {
                options.AddPolicy("AllowAll", policy =>
                {
                    policy
                        .AllowAnyOrigin()
                        .AllowAnyHeader()
                        .AllowAnyMethod();
                });
            });

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseCors("AllowAll");

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
