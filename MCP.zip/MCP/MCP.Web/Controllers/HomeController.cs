using MCP.Web.Models;
using MCP.Web.Services.ApiService;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace MCP.Web.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly IApiService _apiService;
        public HomeController(ILogger<HomeController> logger, IApiService apiService)
        {
            _logger = logger;
            _apiService = apiService;
        }

        public async Task<IActionResult> Index()
        {
            if (String.IsNullOrWhiteSpace(_apiService.GetToken()))
            {
                await _apiService.AuthenticateContact();
            }
            return View();
        }

        [HttpPost]
        public async Task Index([FromBody] string prompt)
        {
            Response.Headers.Append("Content-Type", "text/event-stream");
            Response.Headers.Append("Cache-Control", "no-cache");
            Response.Headers.Append("Connection", "keep-alive");
            Response.Headers.Append("X-Accel-Buffering", "no");

            var syncIOFeature = HttpContext.Features.Get<Microsoft.AspNetCore.Http.Features.IHttpBodyControlFeature>();
            if (syncIOFeature != null)
            {
                syncIOFeature.AllowSynchronousIO = false;
            }

            try
            {
                await foreach (var chunk in _apiService.GetResultStream(prompt))
                {
                    await Response.WriteAsync($"data: {chunk}\n\n");
                    await Response.Body.FlushAsync();
                }

                await Response.WriteAsync("data: [DONE]\n\n");
                await Response.Body.FlushAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error streaming response");
                await Response.WriteAsync($"data: {{\"type\":\"error\",\"message\":\"{ex.Message}\"}}\n\n");
                await Response.Body.FlushAsync();
            }
        }


    }
}
