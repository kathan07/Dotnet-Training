﻿using Flurl.Http;
using MCP.Core.Chat;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json.Nodes;

namespace MCP.Web.Services.ApiService
{
    public class ApiService : IApiService
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly string _accessToken;
        public ApiService(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _accessToken = "Access_Token";
        }

        public string? GetToken()
        {
            return _httpContextAccessor.HttpContext?.Request.Cookies[_accessToken];
        }

        public void SetToken(string token)
        {
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Secure = true,
                SameSite = SameSiteMode.Strict
            };

            var context = _httpContextAccessor.HttpContext;
            context?.Response.Cookies.Delete(_accessToken);
            context?.Response.Cookies.Append(_accessToken, token, cookieOptions);
        }

        public async Task<string> AuthenticateContact()
        {
            var res = await "https://qa-kinetic.rmis360.com/api/v1/Login/authenticate-contact"
                .WithHeaders(new { Accept = "text/plain", Content_Type = "application/json-patch+json" })
                .PostJsonAsync(new
                {
                    contactId = 0,
                    contactProtectedId = (string?)null,
                    loginDeviceId = 0,
                    loginDeviceProtectedId = (string?)null,
                    userName = "MUY3RmF6Rk9EL2p2b2VpSDZuQlJvTEJmUE43T1VBeDB5enk2YnRCeVRDcz0=",
                    password = "e86f78a8a3caf0b60d8e74e5942aa6d86dc150cd3c03338aef25b7d2d7e3acc7",
                    rememberMe = false,
                    forgotPassword = false,
                    hasDeviceInformation = false,
                    deviceInfo = new
                    {
                        deviceId = 6961417175253459,
                        device = (string?)null,
                        deviceType = (string?)null,
                        browserName = "Edge",
                        browserVersion = "139.0.0.0",
                        os = "Windows",
                        osVersion = "10",
                        engineName = "Blink",
                        engineVersion = "139.0.0.0",
                        country = "India",
                        state = "Maharashtra",
                        city = "Mumbai",
                        timeZone = "India Standard Time",
                        ipAddress = "14.194.132.166",
                        sessionId = "8f5bfc63-5085-51cb-fd9b-f25dd212a22c"
                    }
                })
                .ReceiveJson<JsonNode>();   // <<---- FIX #2

            // safely read values
            var token = res?["result"]?["jwtAuthResponse"]?["accessToken"]?.GetValue<string>();


            if (token != null) SetToken(token);

            return token;
            
        }

        public async IAsyncEnumerable<string> GetResultStream(string prompt)
        {
            RequestDto body = new RequestDto()
            {
                Prompt = prompt,
                Token = GetToken()
            };

            var response = await "https://localhost:7247/Home"
                                    .PostJsonAsync(body)
                                    .ReceiveStream();

            using var reader = new StreamReader(response);
            string? line;

            // Read line by line instead of character by character
            while ((line = await reader.ReadLineAsync()) != null)
            {
                if (line.StartsWith("data: "))
                {
                    var data = line.Substring(6).Trim();

                    if (data == "[DONE]")
                    {
                        break;
                    }

                    // Pass through the data without re-wrapping
                    yield return data;
                }
            }
        }

        public async Task<string> GetResult(string prompt)
        {
            List<string> results = new List<string>();
            await foreach (var chunk in GetResultStream(prompt))
            {
                results.Add(chunk);
            }
            return string.Join("", results);
        }

    }

}

