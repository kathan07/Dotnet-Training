﻿namespace MCP.Web.Services.ApiService
{
    public interface IApiService
    {
        string? GetToken();
        void SetToken(string token);
        Task<string> AuthenticateContact();
        Task<string> GetResult(string prompt);
        IAsyncEnumerable<string> GetResultStream(string prompt);

    }
}
