﻿$(document).ready(function () {

    // ================================
    // Configure marked.js (Markdown → HTML)
    // with highlight.js for code blocks
    // ================================
    marked.setOptions({
        highlight: function (code, lang) {
            if (lang && hljs.getLanguage(lang)) {
                try {
                    return hljs.highlight(code, { language: lang }).value;
                } catch (err) {
                    console.error('Highlight error:', err);
                }
            }
            return hljs.highlightAuto(code).value;
        },
        breaks: true,
        gfm: true
    });

    let isLoading = false;
    let currentAbortController = null;

    // ===========================================
    // Auto-resize textarea based on content height
    // ===========================================
    $('#userInput').on('input', function () {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
    });

    // ===========================================
    // Enter = Send | Shift+Enter = New Line
    // ===========================================
    $('#userInput').on('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            handleSubmit();
        }
    });

    // ===========================================
    // Send button click
    // ===========================================
    $('#sendBtn').on('click', function () {
        handleSubmit();
    });

    // ===========================================
    // Main submit handler with SSE streaming
    // ===========================================
    function handleSubmit() {
        const inputValue = $('#userInput').val().trim();

        if (!inputValue || isLoading) {
            return;
        }

        $('#welcomeMessage').hide();
        addMessage('prompt', inputValue);
        $('#userInput').val('').css('height', 'auto');
        setLoading(true);

        // Create abort controller for cancellation
        currentAbortController = new AbortController();

        // Start streaming with typing effect
        streamWithTypingEffect(inputValue);
    }

    // ===========================================
    // Progressive status states
    // ===========================================
    function showProgressiveStatus() {
        const statuses = [
            '🔍 Understanding your query...',
            '📡 Fetching data...',
            '✨ Formatting response...',
            '🧠 Thinking deeply...',
            '⚙️ Running smart checks...',
            '📖 Analyzing context...',
            '🔧 Using available tools...',
            '💡 Generating insights...',
            '📝 Drafting the reply...',
            '📦 Packaging the final answer...',
            '🔄 Refining the response...',
            '📊 Processing results...',
            '🔐 Validating details...',
            '🌐 Connecting to sources...',
            '🔎 Double-checking facts...',
            '⏳ Wrapping things up...',
            '🚀 Almost ready...',
        ];

        let currentStatus = 0;
        const $statusContainer = $('.message.loading .message-content');

        // Show first status immediately
        $statusContainer.html(`<div class="status-text">${statuses[0]}</div>`);

        // Rotate through statuses every 2 seconds
        const statusInterval = setInterval(() => {
            currentStatus = (currentStatus + 1) % statuses.length;
            const $currentStatus = $('.message.loading .message-content');
            if ($currentStatus.length > 0) {
                $currentStatus.html(`<div class="status-text">${statuses[currentStatus]}</div>`);
            } else {
                clearInterval(statusInterval);
            }
        }, 2000);

        return statusInterval;
    }

    // ===========================================
    // Stream with character-by-character typing effect
    // ===========================================
    function streamWithTypingEffect(inputValue) {
        let fullText = '';
        let displayedText = '';
        let typingInterval = null;
        let statusInterval = null;
        let hasReceivedFirstChunk = false;
        let $messageContent = null;

        // Start progressive status
        statusInterval = showProgressiveStatus();

        // Character-by-character typing function
        function typeCharacters() {
            if (displayedText.length < fullText.length) {
                const charsToAdd = 3; // Characters per tick
                displayedText = fullText.substring(0, displayedText.length + charsToAdd);

                // Render with cursor
                const renderedMarkdown = marked.parse(displayedText);
                $messageContent.html(renderedMarkdown + '<span class="streaming-cursor">▋</span>');

                // Highlight code blocks
                $messageContent.find('pre code').each(function () {
                    hljs.highlightElement(this);
                });

                scrollToBottom();
            }
        }

        function startTypingEffect() {
            if (!hasReceivedFirstChunk) {
                hasReceivedFirstChunk = true;

                // Clear status interval
                if (statusInterval) {
                    clearInterval(statusInterval);
                }

                // Remove loading indicator
                $('.message.loading').remove();

                // Create streaming message container with cursor
                const messageHtml = `
                    <div class="message response">
                        <div class="message-content" data-streaming="true">
                            <span class="streaming-cursor">▋</span>
                        </div>
                    </div>
                `;
                $('#messagesContainer').append(messageHtml);
                $messageContent = $('.message.response:last .message-content');

                // Start typing interval
                typingInterval = setInterval(typeCharacters, 20);

                scrollToBottom();
            }
        }

        // Fetch SSE stream
        fetch('https://localhost:7054/Home', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'text/event-stream'
            },
            body: JSON.stringify(inputValue),
            signal: currentAbortController.signal
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';

                function processStream() {
                    reader.read().then(({ done, value }) => {
                        if (done) {
                            // Wait for typing to finish
                            const finishTyping = setInterval(() => {
                                if (displayedText.length >= fullText.length) {
                                    clearInterval(finishTyping);
                                    clearInterval(typingInterval);
                                    if (statusInterval) clearInterval(statusInterval);

                                    // Finalize message
                                    const renderedMarkdown = marked.parse(fullText);
                                    $messageContent.html(renderedMarkdown);
                                    $messageContent.attr('data-streaming', 'false');

                                    $messageContent.find('pre code').each(function () {
                                        hljs.highlightElement(this);
                                    });

                                    setLoading(false);
                                    scrollToBottom();
                                }
                            }, 50);
                            return;
                        }

                        // Decode the chunk
                        buffer += decoder.decode(value, { stream: true });
                        const lines = buffer.split('\n');
                        buffer = lines.pop() || '';

                        // Process each complete line
                        lines.forEach(line => {
                            if (line.startsWith('data: ')) {
                                const data = line.substring(6).trim();

                                if (data === '[DONE]') {
                                    return;
                                }

                                if (data.startsWith('{')) {
                                    try {
                                        const parsed = JSON.parse(data);

                                        if (parsed.type === 'text') {
                                            // Start typing effect on first chunk
                                            startTypingEffect();

                                            // Accumulate text for typing effect
                                            fullText += parsed.content;
                                        }
                                    } catch (e) {
                                        console.error('Error parsing JSON:', e, data);
                                    }
                                }
                            }
                        });

                        // Continue reading stream
                        processStream();

                    }).catch(error => {
                        if (typingInterval) clearInterval(typingInterval);
                        if (statusInterval) clearInterval(statusInterval);

                        if (error.name === 'AbortError') {
                            console.log('Stream aborted by user');
                        } else {
                            console.error('Stream reading error:', error);

                            // Remove loading and show error
                            $('.message.loading').remove();

                            if ($messageContent) {
                                $messageContent.html('Error: Failed to read stream. Please try again.');
                                $messageContent.attr('data-streaming', 'false');
                            } else {
                                addMessage('response', 'Error: Failed to read stream. Please try again.', false);
                            }
                        }
                        setLoading(false);
                    });
                }

                processStream();

            })
            .catch(error => {
                if (typingInterval) clearInterval(typingInterval);
                if (statusInterval) clearInterval(statusInterval);

                if (error.name === 'AbortError') {
                    console.log('Request aborted');
                } else {
                    console.error('Fetch error:', error);

                    // Remove loading and show error
                    $('.message.loading').remove();
                    addMessage('response', 'Error: Failed to connect. Please try again.', false);
                }
                setLoading(false);
            });
    }

    // ===========================================
    // Add a static message to chat
    // ===========================================
    function addMessage(type, text, isStreaming = false) {
        const messageHtml = `
            <div class="message ${type}">
                <div class="message-content" data-streaming="${isStreaming}">
                    ${type === 'response' ? '' : escapeHtml(text)}
                </div>
            </div>
        `;

        $('#messagesContainer').append(messageHtml);

        if (type === 'response' && !isStreaming) {
            const $lastMessage = $('.message.response:last .message-content');
            const renderedMarkdown = marked.parse(text);
            $lastMessage.html(renderedMarkdown);

            $lastMessage.find('pre code').each(function () {
                hljs.highlightElement(this);
            });
        }

        scrollToBottom();
    }

    // ===========================================
    // Handle loading state
    // ===========================================
    function setLoading(loading) {
        isLoading = loading;

        $('#userInput').prop('disabled', loading);
        $('#sendBtn').prop('disabled', loading);

        if (loading) {
            const typingHtml = `
                <div class="message response loading">
                    <div class="message-content">
                        <div class="status-text">🔍 Understanding your query...</div>
                    </div>
                </div>
            `;
            $('#messagesContainer').append(typingHtml);
            scrollToBottom();
        } else {
            $('.message.loading').remove();
        }
    }

    function scrollToBottom() {
        const messagesContainer = $('#messagesContainer')[0];
        if (messagesContainer) {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    }

    function escapeHtml(text) {
        const map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, m => map[m]);
    }

    // Cleanup on page unload
    $(window).on('beforeunload', function () {
        if (currentAbortController) {
            currentAbortController.abort();
        }
    });

});